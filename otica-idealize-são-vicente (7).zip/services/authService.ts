import { User, UserRole } from '../types';

// Extend User type locally to include password for internal auth check
interface MockUser extends User {
  password: string;
}

const MOCK_USERS: MockUser[] = [
  { username: 'supervisor', password: '123', role: UserRole.SUPERVISOR, name: 'Supervisor Geral' },
  { username: 'administrativo', password: '123', role: UserRole.ADMINISTRATIVO, name: 'Atendimento' },
  { username: 'montagem', password: '123', role: UserRole.MONTAGEM, name: 'Técnico Montagem' }
];

export const AuthService = {
  login: (username: string, password: string): User | null => {
    const user = MOCK_USERS.find(u => 
      u.username.toLowerCase() === username.toLowerCase() && 
      u.password === password
    );
    
    if (user) {
      // Return user data without the password
      const { password, ...safeUser } = user;
      return safeUser;
    }
    return null;
  },

  getCurrentUser: (): User | null => {
    const stored = localStorage.getItem('optoflow_user');
    return stored ? JSON.parse(stored) : null;
  },

  saveUserSession: (user: User) => {
    localStorage.setItem('optoflow_user', JSON.stringify(user));
  },

  logout: () => {
    localStorage.removeItem('optoflow_user');
  }
};