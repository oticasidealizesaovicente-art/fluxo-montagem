// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// TODO: SUBSTITUA COM SUAS CHAVES DO FIREBASE AQUI
// Vá em Project Settings -> General -> Your apps -> SDK setup and configuration -> Config
const firebaseConfig = {
  apiKey: "AIzaSyAUpmastLiQe4pR6hymGbBPhI8bYv6QrlI",
  authDomain: "otica-idealize.firebaseapp.com",
  projectId: "otica-idealize",
  storageBucket: "otica-idealize.firebasestorage.app",
  messagingSenderId: "249461454360",
  appId: "1:249461454360:web:0a4cb52607dd42e4b5356d"
};


// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);