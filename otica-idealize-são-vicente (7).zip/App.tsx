import React, { useState, useEffect, useMemo } from 'react';
import { Order, OrderStatus, User, UserRole } from './types';
import { StorageService } from './services/storageService';
import { AuthService } from './services/authService';
import { Card } from './components/Card';
import { OrderForm } from './components/OrderForm';
import { SupervisorReport } from './components/SupervisorReport';
import { InventoryView } from './components/InventoryView';
import { Login } from './components/Login';
import { Plus, Search, RefreshCw, LogOut, FileText, Kanban, Calendar, X, Filter, Grid, Wifi } from 'lucide-react';

const COLUMN_COLORS: Record<OrderStatus, string> = {
  [OrderStatus.FEITOS]: 'border-t-gray-500',
  [OrderStatus.AGUARDANDO]: 'border-t-red-500',
  [OrderStatus.MONTAGEM]: 'border-t-blue-500',
  [OrderStatus.FINALIZADOS]: 'border-t-brand-teal',
  [OrderStatus.AVISADOS]: 'border-t-purple-500',
  [OrderStatus.ENTREGUES]: 'border-t-slate-600',
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  
  // Search & Filter State
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilterType, setDateFilterType] = useState<'purchase' | 'delivery'>('purchase');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const [loading, setLoading] = useState(true);
  
  // View state: 'kanban', 'report', 'inventory'
  const [view, setView] = useState<'kanban' | 'report' | 'inventory'>('kanban');

  // Check login status on mount
  useEffect(() => {
    const savedUser = AuthService.getCurrentUser();
    if (savedUser) {
      setUser(savedUser);
    } else {
      setLoading(false);
    }
  }, []);

  // REAL-TIME SUBSCRIPTION
  useEffect(() => {
    if (!user) return;

    setLoading(true);
    // subscribeToOrders returns an unsubscribe function
    const unsubscribe = StorageService.subscribeToOrders((data) => {
        setOrders(data);
        setLoading(false);
    });

    // Cleanup listener on unmount
    return () => unsubscribe();
  }, [user]);

  const handleLoginSuccess = (loggedInUser: User) => {
    setUser(loggedInUser);
  };

  const handleLogout = () => {
    AuthService.logout();
    setUser(null);
    setView('kanban');
  };

  const handleSaveOrder = async (order: Order, isNew: boolean) => {
    // Validation
    const existingOrder = orders.find(o => o.osNumber === order.osNumber && o.id !== order.id);
    if (existingOrder) {
      alert(`Erro: A OS número "${order.osNumber}" já existe no sistema.`);
      return; 
    }

    try {
        await StorageService.saveOrder(order, isNew);
        setIsFormOpen(false);
        setEditingOrder(null);
    } catch (error) {
        console.error("Error saving:", error);
        alert("Erro ao salvar. Verifique sua conexão.");
    }
  };

  const handleDeleteOrder = async (id: string) => {
    if (user?.role !== UserRole.SUPERVISOR) {
      alert("Permissão negada. Apenas supervisores podem excluir.");
      return;
    }

    if (confirm('Tem certeza que deseja excluir esta OS?')) {
      await StorageService.deleteOrder(id);
    }
  };

  const handleStatusChange = async (id: string, newStatus: OrderStatus) => {
    // Optimistic update for UI responsiveness
    setOrders(prev => prev.map(o => o.id === id ? { ...o, status: newStatus } : o));
    await StorageService.updateStatus(id, newStatus);
  };

  const handleRedoOrder = async (id: string, reason: string) => {
    if (user?.role !== UserRole.SUPERVISOR) {
      alert("Permissão negada.");
      return;
    }

    const order = orders.find(o => o.id === id);
    if (!order) return;

    await StorageService.saveOrder({
      ...order,
      status: OrderStatus.AGUARDANDO,
      redoReason: reason,
      updatedAt: Date.now(),
      statusHistory: [
        ...order.statusHistory,
        { status: OrderStatus.AGUARDANDO, timestamp: Date.now() }
      ]
    }, false); 
  };

  const openNewOrder = () => {
    setEditingOrder(null);
    setIsFormOpen(true);
  };

  const openEditOrder = (order: Order) => {
    if (user?.role !== UserRole.SUPERVISOR) {
      alert("Permissão negada.");
      return;
    }
    setEditingOrder(order);
    setIsFormOpen(true);
  };

  const clearDateFilters = () => {
    setStartDate('');
    setEndDate('');
  };

  const filteredOrders = useMemo(() => {
    let result = orders;

    if (searchTerm) {
      const lower = searchTerm.toLowerCase();
      result = result.filter(o => {
        if (o.osNumber.toLowerCase().includes(lower)) return true;
        if (o.orderNumber.toLowerCase().includes(lower)) return true;
        if (o.additionalOrders && o.additionalOrders.some(ao => ao.toLowerCase().includes(lower))) return true;
        return false;
      });
    }

    if (startDate || endDate) {
      result = result.filter(o => {
        const dateString = dateFilterType === 'purchase' ? o.purchaseDate : o.deliveryDate;
        if (!dateString) return false;
        const date = dateString.substring(0, 10);
        
        if (startDate && date < startDate) return false;
        if (endDate && date > endDate) return false;
        
        return true;
      });
    }
    
    return result;
  }, [orders, searchTerm, startDate, endDate, dateFilterType]);

  const canCreate = user && (user.role === UserRole.SUPERVISOR || user.role === UserRole.ADMINISTRATIVO);
  const isSupervisor = user && user.role === UserRole.SUPERVISOR;

  if (!user) {
    return <Login onLoginSuccess={handleLoginSuccess} />;
  }

  // --- VIEWS RENDERER ---
  const renderContent = () => {
    if (view === 'report') {
        return <SupervisorReport orders={orders} onBack={() => setView('kanban')} />;
    }
    if (view === 'inventory') {
        return <InventoryView user={user} onBack={() => setView('kanban')} />;
    }
    
    // KANBAN VIEW
    return (
        <div className="flex-1 overflow-x-auto overflow-y-hidden p-2">
            <div className="flex min-w-[1000px] h-full gap-2">
              {Object.values(OrderStatus).map((status) => {
                const statusOrders = filteredOrders.filter(o => o.status === status);
                return (
                  <div key={status} className="flex-1 flex flex-col min-w-[200px] max-w-[300px] h-full">
                    {/* Column Header */}
                    <div className={`bg-white border border-gray-200 border-t-4 ${COLUMN_COLORS[status]} px-2 py-2 rounded-t-md shadow-sm mb-2 flex justify-between items-center`}>
                      <h3 className="font-bold text-gray-800 text-xs tracking-wide uppercase truncate">{status}</h3>
                      <span className="bg-brand-light text-brand-teal text-[10px] px-2 py-0.5 rounded-full border border-gray-200 font-bold">
                        {statusOrders.length}
                      </span>
                    </div>

                    {/* Column Content */}
                    <div className="flex-1 bg-gray-200/50 rounded-md p-1.5 overflow-y-auto border border-gray-200">
                      {statusOrders.length === 0 ? (
                        <div className="h-16 flex items-center justify-center text-gray-400 text-[10px] italic border border-dashed border-gray-300 rounded m-1 bg-gray-50/50">
                          {loading ? 'Carregando...' : 'Vazio'}
                        </div>
                      ) : (
                        statusOrders.map(order => (
                          <Card 
                            key={order.id} 
                            order={order} 
                            user={user}
                            onStatusChange={handleStatusChange}
                            onEdit={openEditOrder}
                            onDelete={handleDeleteOrder}
                            onRedo={handleRedoOrder}
                          />
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col font-sans bg-brand-light text-gray-900 overflow-hidden">
      {/* Header Compacto */}
      <header className="bg-white border-b border-gray-200 p-3 sticky top-0 z-30 shadow-sm">
        <div className="flex flex-col xl:flex-row justify-between items-center gap-3">
          <div className="flex items-center gap-2 w-full xl:w-auto">
             <div>
               <h1 className="text-lg font-bold text-brand-teal leading-tight flex items-center gap-2">
                   Fluxo de Montagem <span className="text-[10px] bg-green-100 text-green-700 px-1 rounded flex items-center gap-1"><Wifi size={8}/> Online</span>
               </h1>
               <div className="flex items-center gap-1 text-[10px] text-gray-500 uppercase tracking-wide">
                  <span>Otica Idealize • {user.name}</span>
               </div>
             </div>
          </div>

          <div className="flex flex-col md:flex-row flex-1 w-full gap-2 items-center justify-end">
             
             {/* Filter Bar */}
             <div className="flex items-center gap-2 bg-brand-light border border-gray-200 p-1 rounded-md w-full md:w-auto overflow-x-auto">
                <div className="flex items-center px-2 text-brand-teal">
                    <Filter size={14} />
                </div>
                
                <select 
                  value={dateFilterType}
                  onChange={(e) => setDateFilterType(e.target.value as 'purchase' | 'delivery')}
                  className="bg-transparent text-xs font-semibold text-gray-700 border-none focus:ring-0 cursor-pointer outline-none"
                >
                    <option value="purchase">Compra</option>
                    <option value="delivery">Entrega</option>
                </select>

                <div className="h-4 w-px bg-gray-300 mx-1"></div>

                <input 
                  type="date" 
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="bg-white border border-gray-300 rounded px-1 py-0.5 text-xs text-gray-700 w-24 focus:ring-1 focus:ring-brand-teal outline-none"
                  title="Data Inicial"
                />
                <span className="text-gray-400 text-xs">até</span>
                <input 
                  type="date" 
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="bg-white border border-gray-300 rounded px-1 py-0.5 text-xs text-gray-700 w-24 focus:ring-1 focus:ring-brand-teal outline-none"
                  title="Data Final"
                />

                {(startDate || endDate) && (
                    <button 
                        onClick={clearDateFilters}
                        className="ml-1 text-gray-400 hover:text-brand-orange rounded p-0.5 transition-colors"
                        title="Limpar datas"
                    >
                        <X size={14} />
                    </button>
                )}
             </div>

             <div className="relative flex-1 w-full md:max-w-xs">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-teal" size={16} />
                <input 
                  type="text" 
                  placeholder="Buscar OS, Pedido..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-brand-light border border-gray-200 text-gray-900 pl-9 pr-3 py-1.5 rounded-md text-sm focus:ring-1 focus:ring-brand-teal outline-none transition-all placeholder-gray-400 focus:bg-white shadow-inner"
                />
             </div>
             
             <div className="flex gap-2 w-full md:w-auto">
                {isSupervisor && (
                    <>
                    <button
                        onClick={() => setView(view === 'report' ? 'kanban' : 'report')}
                        className={`px-3 py-1.5 rounded-md text-sm font-medium flex items-center justify-center gap-1 shadow-sm whitespace-nowrap transition-colors flex-1 md:flex-none
                            ${view === 'report' ? 'bg-brand-teal text-white border border-transparent' : 'bg-white border border-gray-200 text-gray-600 hover:bg-brand-light hover:text-brand-teal'}
                        `}
                    >
                        <FileText size={16} />
                        <span className="hidden sm:inline">Relatório</span>
                    </button>
                    <button
                        onClick={() => setView(view === 'inventory' ? 'kanban' : 'inventory')}
                        className={`px-3 py-1.5 rounded-md text-sm font-medium flex items-center justify-center gap-1 shadow-sm whitespace-nowrap transition-colors flex-1 md:flex-none
                            ${view === 'inventory' ? 'bg-brand-orange text-white border border-transparent' : 'bg-white border border-gray-200 text-gray-600 hover:bg-brand-light hover:text-brand-orange'}
                        `}
                    >
                        <Grid size={16} />
                        <span className="hidden sm:inline">Estoque</span>
                    </button>
                    </>
                )}
                
                {!isSupervisor && (user.role === UserRole.ADMINISTRATIVO || user.role === UserRole.MONTAGEM) && (
                    <button
                        onClick={() => setView(view === 'inventory' ? 'kanban' : 'inventory')}
                        className={`px-3 py-1.5 rounded-md text-sm font-medium flex items-center justify-center gap-1 shadow-sm whitespace-nowrap transition-colors flex-1 md:flex-none
                            ${view === 'inventory' ? 'bg-brand-orange text-white border border-transparent' : 'bg-white border border-gray-200 text-gray-600 hover:bg-brand-light hover:text-brand-orange'}
                        `}
                    >
                        <Grid size={16} />
                        <span className="hidden sm:inline">Estoque</span>
                    </button>
                )}

                {canCreate && view === 'kanban' && (
                <button 
                    onClick={openNewOrder}
                    className="bg-brand-teal hover:opacity-90 text-white px-3 py-1.5 rounded-md text-sm font-medium flex items-center justify-center gap-1 shadow-sm whitespace-nowrap flex-1 md:flex-none transition-all"
                >
                    <Plus size={16} /> <span className="hidden sm:inline">Criar</span>
                </button>
                )}

                <button 
                onClick={handleLogout}
                className="bg-white border border-gray-200 hover:bg-red-50 hover:text-red-600 text-gray-600 p-1.5 rounded-md shadow-sm transition-colors"
                title="Sair"
                >
                    <LogOut size={16} />
                </button>
             </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-hidden relative flex flex-col">
        {renderContent()}
      </main>

      {/* Modal Form */}
      {isFormOpen && (
        <OrderForm 
          initialData={editingOrder}
          onSave={handleSaveOrder}
          onCancel={() => setIsFormOpen(false)}
        />
      )}
    </div>
  );
}