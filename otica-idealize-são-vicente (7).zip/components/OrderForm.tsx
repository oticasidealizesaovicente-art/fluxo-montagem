import React, { useState, useEffect } from 'react';
import { Order, OrderStatus, SaleType, DeadlineType, LensDetails } from '../types';
import { X, Save, ArrowLeft, Plus, Trash2, Eye, AlertTriangle } from 'lucide-react';
import { StorageService } from '../services/storageService';

interface OrderFormProps {
  initialData?: Order | null;
  onSave: (order: Order, isNew: boolean) => void;
  onCancel: () => void;
}

// Helper to get local date string YYYY-MM-DD safely
const getTodayString = () => {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

// Ranges for Select Inputs
const SPHERE_OPTIONS = [];
for (let i = 4.00; i >= -4.00; i -= 0.25) {
    const val = i === 0 ? '+0.00' : (i > 0 ? `+${i.toFixed(2)}` : i.toFixed(2));
    SPHERE_OPTIONS.push(val);
}

const CYL_OPTIONS = [];
for (let i = 0.00; i >= -2.00; i -= 0.25) {
    CYL_OPTIONS.push(i === 0 ? '-0.00' : i.toFixed(2));
}

export const OrderForm: React.FC<OrderFormProps> = ({ initialData, onSave, onCancel }) => {
  // State to manage multiple order numbers (glasses)
  const [orderNumbers, setOrderNumbers] = useState<string[]>(['']);
  
  const [formData, setFormData] = useState<Partial<Order>>({
    osNumber: '',
    saleType: SaleType.VENDA,
    deadlineType: DeadlineType.PEDIDO,
    purchaseDate: getTodayString(),
    deliveryDate: '',
    status: OrderStatus.FEITOS, 
  });

  const [lensDetails, setLensDetails] = useState<LensDetails>({ 
      odSph: '-0.00', odCyl: '-0.00', 
      oeSph: '-0.00', oeCyl: '-0.00' 
  });

  // State to hold real-time stock levels
  const [stockLevels, setStockLevels] = useState({ od: 10, oe: 10 });
  const [loadingStock, setLoadingStock] = useState(false);

  const showStockLensInputs = (formData.deadlineType === DeadlineType.NA_HORA) && 
                              (formData.saleType === SaleType.VENDA || formData.saleType === SaleType.GARANTIA);

  useEffect(() => {
    if (initialData) {
      setFormData({
        ...initialData,
        purchaseDate: initialData.purchaseDate.substring(0, 10),
        deliveryDate: initialData.deliveryDate.substring(0, 10)
      });
      // Populate order numbers list (Primary + Additional)
      const allOrders = [initialData.orderNumber];
      if (initialData.additionalOrders && initialData.additionalOrders.length > 0) {
        allOrders.push(...initialData.additionalOrders);
      }
      setOrderNumbers(allOrders);
      
      if (initialData.lensDetails) {
          setLensDetails(initialData.lensDetails);
      }
    } else {
       calculateDeliveryDate(formData.deadlineType as DeadlineType, formData.purchaseDate!);
    }
  }, [initialData]);

  const calculateDeliveryDate = (type: DeadlineType, purchaseDateStr: string) => {
      if (!purchaseDateStr || purchaseDateStr.length < 10) return;

      const cleanDateStr = purchaseDateStr.substring(0, 10);

      if (type === DeadlineType.PEDIDO) {
          const [yearStr, monthStr, dayStr] = cleanDateStr.split('-');
          const year = parseInt(yearStr);
          const month = parseInt(monthStr) - 1;
          const day = parseInt(dayStr);

          const date = new Date(year, month, day, 12, 0, 0); 
          date.setDate(date.getDate() + 10);
          
          const newYear = date.getFullYear();
          const newMonth = String(date.getMonth() + 1).padStart(2, '0');
          const newDay = String(date.getDate()).padStart(2, '0');
          
          setFormData(prev => ({ ...prev, deliveryDate: `${newYear}-${newMonth}-${newDay}` }));
      } else if (type === DeadlineType.NA_HORA) {
          setFormData(prev => ({ ...prev, deliveryDate: cleanDateStr }));
      }
  };

  useEffect(() => {
     if (formData.deadlineType && formData.purchaseDate) {
         calculateDeliveryDate(formData.deadlineType, formData.purchaseDate);
     }
  }, [formData.deadlineType, formData.purchaseDate]);

  // Check stock levels whenever lens details change or mode changes
  useEffect(() => {
      const fetchStock = async () => {
          if (showStockLensInputs) {
              setLoadingStock(true);
              const odCount = await StorageService.getLensStockAsync(lensDetails.odSph || '', lensDetails.odCyl || '');
              const oeCount = await StorageService.getLensStockAsync(lensDetails.oeSph || '', lensDetails.oeCyl || '');
              setStockLevels({ od: odCount, oe: oeCount });
              setLoadingStock(false);
          }
      };
      
      fetchStock();
  }, [lensDetails, showStockLensInputs]);

  const handleOrderNumberChange = (index: number, value: string) => {
    const newOrders = [...orderNumbers];
    newOrders[index] = value;
    setOrderNumbers(newOrders);
  };

  const addOrderField = () => {
    setOrderNumbers([...orderNumbers, '']);
  };

  const removeOrderField = (index: number) => {
    if (orderNumbers.length > 1) {
      const newOrders = orderNumbers.filter((_, i) => i !== index);
      setOrderNumbers(newOrders);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.osNumber || !orderNumbers[0] || !formData.deliveryDate) {
        alert("Preencha os campos obrigatórios (*)");
        return;
    }

    const validOrders = orderNumbers.filter(o => o.trim() !== '');
    if (validOrders.length === 0) {
        alert("Insira pelo menos um número de pedido.");
        return;
    }

    const primaryOrderNumber = validOrders[0];
    const additionalOrders = validOrders.slice(1);
    
    const now = Date.now();
    const isNew = !initialData;

    const needsStockLens = (formData.deadlineType === DeadlineType.NA_HORA) && 
                           (formData.saleType === SaleType.VENDA || formData.saleType === SaleType.GARANTIA);

    const cleanLensDetails: LensDetails = needsStockLens ? {
        odSph: lensDetails.odSph?.replace('+', ''), 
        odCyl: lensDetails.odCyl,
        oeSph: lensDetails.oeSph?.replace('+', ''),
        oeCyl: lensDetails.oeCyl
    } : {};

    const orderToSave: Order = {
      id: initialData?.id || crypto.randomUUID(),
      osNumber: formData.osNumber!,
      orderNumber: primaryOrderNumber,
      additionalOrders: additionalOrders,
      customerName: '', 
      saleType: formData.saleType as SaleType,
      deadlineType: formData.deadlineType as DeadlineType,
      purchaseDate: formData.purchaseDate!,
      deliveryDate: formData.deliveryDate!,
      status: formData.status as OrderStatus,
      createdAt: initialData?.createdAt || now,
      updatedAt: initialData?.updatedAt || now,
      statusHistory: initialData?.statusHistory || (isNew ? [{ status: formData.status as OrderStatus, timestamp: now }] : []),
      lensDetails: needsStockLens ? cleanLensDetails : undefined
    };

    onSave(orderToSave, isNew);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white border border-gray-200 rounded-xl w-full max-w-lg shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
          <h2 className="text-lg font-bold text-gray-800">
            {initialData ? 'Editar Ordem' : 'Nova OS'}
          </h2>
          <button onClick={onCancel} className="text-gray-400 hover:text-gray-600 transition-colors">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto">
          
          <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">ID OS *</label>
              <input
                type="text"
                value={formData.osNumber}
                onChange={e => setFormData({...formData, osNumber: e.target.value})}
                className="w-full bg-white border border-gray-300 rounded-md p-2 text-sm text-gray-900 focus:ring-2 focus:ring-brand-teal outline-none transition-all"
                placeholder="Ex: 231323"
                autoFocus
                disabled={!!initialData}
              />
          </div>

          <div>
             <label className="block text-xs font-semibold text-gray-700 mb-2">
                 Nº Pedido(s) / Óculos *
             </label>
             <div className="space-y-2">
                 {orderNumbers.map((num, index) => (
                     <div key={index} className="flex gap-2 items-center">
                         <div className="relative w-full">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xs font-bold">
                                #{index + 1}
                            </span>
                            <input
                                type="text"
                                value={num}
                                onChange={e => handleOrderNumberChange(index, e.target.value)}
                                className="w-full bg-white border border-gray-300 rounded-md py-2 pl-8 pr-2 text-sm text-gray-900 focus:ring-2 focus:ring-brand-teal outline-none"
                                placeholder={`Pedido ${index + 1}`}
                            />
                         </div>
                         
                         {orderNumbers.length > 1 && (
                             <button 
                                type="button" 
                                onClick={() => removeOrderField(index)}
                                className="text-red-400 hover:text-red-600 p-1.5 hover:bg-red-50 rounded"
                                title="Remover pedido"
                             >
                                 <Trash2 size={16} />
                             </button>
                         )}
                     </div>
                 ))}
             </div>
             <button 
                type="button" 
                onClick={addOrderField}
                className="mt-2 text-xs font-semibold text-brand-teal hover:text-teal-700 flex items-center gap-1 hover:bg-teal-50 px-2 py-1 rounded transition-colors"
             >
                <Plus size={14} /> Adicionar outro óculos
             </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Tipo de Venda</label>
              <select
                value={formData.saleType}
                onChange={e => setFormData({...formData, saleType: e.target.value as SaleType})}
                className="w-full bg-white border border-gray-300 rounded-md p-2 text-sm text-gray-900 focus:ring-2 focus:ring-brand-teal outline-none"
              >
                {Object.values(SaleType).map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Prioridade</label>
              <select
                value={formData.deadlineType}
                onChange={e => setFormData({...formData, deadlineType: e.target.value as DeadlineType})}
                className="w-full bg-white border border-gray-300 rounded-md p-2 text-sm text-gray-900 focus:ring-2 focus:ring-brand-teal outline-none"
              >
                {Object.values(DeadlineType).map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
          </div>

          {/* Structured Input for Stock Lens - Using Brand Orange for Inventory/Warning styling */}
          {showStockLensInputs && (
             <div className="bg-orange-50 border border-brand-orange/30 rounded-md p-3 animate-in fade-in slide-in-from-top-2">
                 <div className="flex items-center gap-2 mb-2 text-brand-orange justify-between">
                     <div className="flex items-center gap-2">
                        <Eye size={16} />
                        <h3 className="text-sm font-bold uppercase">Baixa no Estoque</h3>
                     </div>
                     <span className="text-[10px] bg-brand-orange text-white px-2 py-0.5 rounded font-bold">Automático</span>
                 </div>
                 
                 <div className="space-y-3">
                     {/* OD ROW */}
                     <div className="grid grid-cols-5 gap-2 items-center">
                         <div className="col-span-1 flex flex-col items-end">
                            <span className="text-[10px] font-bold text-gray-600 uppercase">OD</span>
                            {!loadingStock && stockLevels.od < 3 && (
                                <span className="flex items-center text-[9px] font-bold text-red-600 bg-red-100 px-1 rounded">
                                    <AlertTriangle size={8} className="mr-0.5" /> Restam {stockLevels.od}
                                </span>
                            )}
                         </div>
                         <div className="col-span-2">
                            <label className="block text-[8px] text-gray-500 mb-0.5">Esférico</label>
                            <select
                                value={lensDetails.odSph || '-0.00'}
                                onChange={e => setLensDetails({...lensDetails, odSph: e.target.value})}
                                className="w-full bg-white border border-brand-orange/40 rounded p-1 text-xs outline-none focus:ring-1 focus:ring-brand-orange"
                            >
                                {SPHERE_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                            </select>
                         </div>
                         <div className="col-span-2">
                            <label className="block text-[8px] text-gray-500 mb-0.5">Cilíndrico</label>
                            <select
                                value={lensDetails.odCyl || '-0.00'}
                                onChange={e => setLensDetails({...lensDetails, odCyl: e.target.value})}
                                className="w-full bg-white border border-brand-orange/40 rounded p-1 text-xs outline-none focus:ring-1 focus:ring-brand-orange"
                            >
                                {CYL_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                            </select>
                         </div>
                     </div>
                     
                     {/* OE ROW */}
                     <div className="grid grid-cols-5 gap-2 items-center">
                         <div className="col-span-1 flex flex-col items-end">
                            <span className="text-[10px] font-bold text-gray-600 uppercase">OE</span>
                            {!loadingStock && stockLevels.oe < 3 && (
                                <span className="flex items-center text-[9px] font-bold text-red-600 bg-red-100 px-1 rounded">
                                    <AlertTriangle size={8} className="mr-0.5" /> Restam {stockLevels.oe}
                                </span>
                            )}
                         </div>
                         <div className="col-span-2">
                            <select
                                value={lensDetails.oeSph || '-0.00'}
                                onChange={e => setLensDetails({...lensDetails, oeSph: e.target.value})}
                                className="w-full bg-white border border-brand-orange/40 rounded p-1 text-xs outline-none focus:ring-1 focus:ring-brand-orange"
                            >
                                {SPHERE_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                            </select>
                         </div>
                         <div className="col-span-2">
                            <select
                                value={lensDetails.oeCyl || '-0.00'}
                                onChange={e => setLensDetails({...lensDetails, oeCyl: e.target.value})}
                                className="w-full bg-white border border-brand-orange/40 rounded p-1 text-xs outline-none focus:ring-1 focus:ring-brand-orange"
                            >
                                {CYL_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                            </select>
                         </div>
                     </div>
                 </div>
             </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Data Compra</label>
              <input
                type="date"
                value={formData.purchaseDate}
                onChange={e => setFormData({...formData, purchaseDate: e.target.value})}
                className="w-full bg-white border border-gray-300 rounded-md p-2 text-sm text-gray-900 focus:ring-2 focus:ring-brand-teal outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Previsão Entrega *</label>
              <input
                type="date"
                value={formData.deliveryDate}
                onChange={e => setFormData({...formData, deliveryDate: e.target.value})}
                className="w-full bg-white border border-gray-300 rounded-md p-2 text-sm text-gray-900 focus:ring-2 focus:ring-brand-teal outline-none"
              />
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 py-2.5 rounded-lg text-sm font-medium transition-colors flex justify-center items-center gap-2"
            >
              <ArrowLeft size={16} /> Voltar
            </button>
            <button
              type="submit"
              className="flex-1 bg-brand-teal hover:opacity-90 text-white py-2.5 rounded-lg text-sm font-medium transition-all flex justify-center items-center gap-2 shadow-md"
            >
              <Save size={16} /> Salvar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};