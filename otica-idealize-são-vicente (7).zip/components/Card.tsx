import React, { useState } from 'react';
import { Order, OrderStatus, DeadlineType, UserRole, User } from '../types';
import { AlertCircle, Edit2, Trash2, Play, CheckCircle, Bell, Package, ArrowRight, Lock, Glasses, ChevronDown, ChevronUp, RotateCcw, ClipboardList, Clock, Wrench } from 'lucide-react';

interface CardProps {
  order: Order;
  user: User;
  onStatusChange: (id: string, status: OrderStatus) => void;
  onEdit: (order: Order) => void;
  onDelete: (id: string) => void;
  onRedo?: (id: string, reason: string) => void;
}

const statusColorMap: Record<OrderStatus, string> = {
  [OrderStatus.FEITOS]: 'border-l-gray-500',
  [OrderStatus.AGUARDANDO]: 'border-l-red-500',
  [OrderStatus.MONTAGEM]: 'border-l-blue-500',
  [OrderStatus.FINALIZADOS]: 'border-l-green-500',
  [OrderStatus.AVISADOS]: 'border-l-purple-500',
  [OrderStatus.ENTREGUES]: 'border-l-slate-600',
};

// Configuration for the visual icon displayed next to the OS number
const STATUS_VISUAL_CONFIG: Record<OrderStatus, { icon: React.ElementType, color: string }> = {
  [OrderStatus.FEITOS]: { icon: ClipboardList, color: 'text-gray-500' },
  [OrderStatus.AGUARDANDO]: { icon: Clock, color: 'text-red-500' },
  [OrderStatus.MONTAGEM]: { icon: Wrench, color: 'text-blue-500' },
  [OrderStatus.FINALIZADOS]: { icon: CheckCircle, color: 'text-green-500' },
  [OrderStatus.AVISADOS]: { icon: Bell, color: 'text-purple-500' },
  [OrderStatus.ENTREGUES]: { icon: Package, color: 'text-slate-600' },
};

const ACTION_CONFIG: Record<OrderStatus, { next: OrderStatus | null, label: string, icon: React.ElementType, colorClass: string }> = {
  [OrderStatus.FEITOS]: { 
    next: OrderStatus.AGUARDANDO, 
    label: 'Enviar', 
    icon: ArrowRight, 
    colorClass: 'bg-blue-600 hover:bg-blue-700 text-white' 
  },
  [OrderStatus.AGUARDANDO]: { 
    next: OrderStatus.MONTAGEM, 
    label: 'Iniciar', 
    icon: Play, 
    colorClass: 'bg-amber-600 hover:bg-amber-700 text-white' 
  },
  [OrderStatus.MONTAGEM]: { 
    next: OrderStatus.FINALIZADOS, 
    label: 'Concluir', 
    icon: CheckCircle, 
    colorClass: 'bg-green-600 hover:bg-green-700 text-white' 
  },
  [OrderStatus.FINALIZADOS]: { 
    next: OrderStatus.AVISADOS, 
    label: 'Avisar', 
    icon: Bell, 
    colorClass: 'bg-purple-600 hover:bg-purple-700 text-white' 
  },
  [OrderStatus.AVISADOS]: { 
    next: OrderStatus.ENTREGUES, 
    label: 'Entregar', 
    icon: Package, 
    colorClass: 'bg-slate-700 hover:bg-slate-800 text-white' 
  },
  [OrderStatus.ENTREGUES]: { 
    next: null, 
    label: 'OK', 
    icon: CheckCircle, 
    colorClass: 'bg-gray-100 text-gray-400 cursor-default' 
  },
};

// Robust date formatter that ignores timezones completely
const formatDate = (dateString: string) => {
  if (!dateString) return '-';
  const cleanDate = dateString.substring(0, 10);
  const parts = cleanDate.split('-');
  if (parts.length === 3) {
    return `${parts[2]}/${parts[1]}`; 
  }
  return dateString;
};

// Format timestamp to "DD/MM HH:mm"
const formatDateTime = (timestamp: number) => {
    if (!timestamp) return '-';
    const d = new Date(timestamp);
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const hour = String(d.getHours()).padStart(2, '0');
    const min = String(d.getMinutes()).padStart(2, '0');
    return `${day}/${month} ${hour}:${min}`;
};

export const Card: React.FC<CardProps> = ({ order, user, onStatusChange, onEdit, onDelete, onRedo }) => {
  const [showHistory, setShowHistory] = useState(false);
  
  const isUrgent = order.deadlineType === DeadlineType.URGENTE;
  const action = ACTION_CONFIG[order.status];
  const visual = STATUS_VISUAL_CONFIG[order.status];
  const StatusIcon = visual.icon;
  
  // RESTRICT: ONLY SUPERVISOR CAN EDIT OR DELETE
  const isSupervisor = user.role === UserRole.SUPERVISOR;
  
  // Calculate if late
  const daysInCurrentStatus = order.updatedAt ? (Date.now() - order.updatedAt) / (1000 * 60 * 60 * 24) : 0;
  
  // Rules: FEITOS > 3 days, Others > 2 days
  const limit = order.status === OrderStatus.FEITOS ? 3 : 2;
  const isLate = daysInCurrentStatus > limit && order.status !== OrderStatus.ENTREGUES;

  const canPerformAction = (): boolean => {
    if (user.role === UserRole.SUPERVISOR) return true;
    if (user.role === UserRole.ADMINISTRATIVO) {
      return [OrderStatus.FEITOS, OrderStatus.FINALIZADOS, OrderStatus.AVISADOS].includes(order.status);
    }
    if (user.role === UserRole.MONTAGEM) {
      return [OrderStatus.AGUARDANDO, OrderStatus.MONTAGEM].includes(order.status);
    }
    return false;
  };

  const handleAction = () => {
    if (action.next && canPerformAction()) {
      onStatusChange(order.id, action.next);
    }
  };

  const handleRedoClick = () => {
      if (onRedo) {
          const reason = prompt("Motivo para refazer o pedido:");
          if (reason) {
              onRedo(order.id, reason);
          }
      }
  };

  const hasMultipleOrders = order.additionalOrders && order.additionalOrders.length > 0;

  // Helper to render lens text
  const renderLens = (sph?: string, cyl?: string) => {
     if (!sph && !cyl) return '-';
     // If structured data exists
     if (sph !== undefined) {
         return `Sph ${sph} | Cyl ${cyl}`;
     }
     return '-';
  }

  return (
    <div className={`rounded-md p-2 mb-2 shadow-sm border border-gray-200 border-l-[3px] ${statusColorMap[order.status]} hover:shadow-md transition-all group relative flex flex-col ${isLate ? 'ring-2 ring-red-400 ring-offset-1 bg-red-50' : 'bg-white'}`}>
      
      {/* Late Warning Badge */}
      {isLate && (
         <div className="absolute -top-1.5 -left-1.5 z-10 bg-red-500 text-white rounded-full p-1 shadow-sm flex items-center justify-center animate-pulse" title={`ATENÇÃO: Parado há ${Math.floor(daysInCurrentStatus)} dias`}>
             <AlertCircle size={14} />
         </div>
      )}

      {/* Header Compacto */}
      <div className="flex justify-between items-start mb-1">
        <div className="flex items-center gap-2 w-full">
          {/* Status Icon Indicator */}
          <StatusIcon size={14} className={`${visual.color} flex-shrink-0`} strokeWidth={2.5} />

          <span className="text-sm font-bold text-gray-900 leading-none">
            {order.osNumber}
          </span>
          
          {hasMultipleOrders && (
             <span className="flex items-center gap-0.5 text-[9px] bg-blue-50 text-blue-700 px-1 py-0.5 rounded border border-blue-100 font-bold" title="Múltiplos óculos">
                <Glasses size={10} />
                {(order.additionalOrders?.length || 0) + 1}x
             </span>
          )}

          {isUrgent && (
             <span className="ml-auto bg-red-50 text-red-600 border border-red-100 text-[9px] px-1.5 py-0.5 rounded-full font-bold uppercase tracking-tighter">
               Urgente
             </span>
          )}
        </div>
        
        {/* Only Supervisor sees Edit/Delete */}
        {isSupervisor && (
          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity absolute top-1 right-1 bg-white pl-1 shadow-sm rounded border border-gray-100 z-20">
            <button onClick={() => onEdit(order)} className="p-1 hover:bg-gray-100 rounded text-blue-600" title="Editar">
              <Edit2 size={12} />
            </button>
            <button onClick={() => onDelete(order.id)} className="p-1 hover:bg-gray-100 rounded text-red-500" title="Excluir">
              <Trash2 size={12} />
            </button>
          </div>
        )}
      </div>

      {/* Lista de Pedidos Compacta */}
      <div className="flex flex-wrap gap-1 mb-2">
         <span className="text-[10px] text-gray-500 font-medium bg-gray-50/50 px-1 rounded border border-gray-100">
            {order.orderNumber}
         </span>
         {order.additionalOrders?.map((ao, idx) => (
             <span key={idx} className="text-[10px] text-gray-500 font-medium bg-gray-50/50 px-1 rounded border border-gray-100">
                {ao}
             </span>
         ))}
      </div>

      {/* Tags Compactas */}
      <div className="flex gap-1 mb-2">
         <span className={`text-[9px] px-1.5 py-0.5 rounded border ${order.saleType === 'Garantia' ? 'bg-orange-50 border-orange-100 text-orange-700' : 'bg-gray-50/50 border-gray-100 text-gray-600'}`}>
            {order.saleType}
         </span>
         <span className="text-[9px] px-1.5 py-0.5 rounded border bg-gray-50/50 border-gray-100 text-gray-600">
            {order.deadlineType}
         </span>
      </div>
      
      {/* Display Stock Lens Details if available (Na Hora) */}
      {order.lensDetails && (order.lensDetails.odSph || order.lensDetails.oeSph) && (
          <div className="mb-2 bg-yellow-50 border border-yellow-200 p-1 rounded text-[9px] text-yellow-800">
              <div className="font-bold uppercase text-[8px] text-yellow-600 mb-0.5 flex justify-between">
                  <span>Lentes Estoque:</span>
              </div>
              <div className="grid grid-cols-2 gap-x-2 gap-y-0.5">
                  <div className="flex justify-between border-b border-yellow-200/50"><span className="font-bold">OD:</span> <span>{renderLens(order.lensDetails.odSph, order.lensDetails.odCyl)}</span></div>
                  <div className="flex justify-between border-b border-yellow-200/50"><span className="font-bold">OE:</span> <span>{renderLens(order.lensDetails.oeSph, order.lensDetails.oeCyl)}</span></div>
              </div>
          </div>
      )}

      {/* Redo Reason Display */}
      {order.redoReason && (
          <div className="mb-2 bg-orange-100 border border-orange-200 p-1.5 rounded text-[10px] text-orange-800">
              <span className="font-bold">Refazer:</span> {order.redoReason}
          </div>
      )}

      {/* Datas Compactas (Linha Única) */}
      <div className="flex justify-between items-center text-[10px] text-gray-500 mb-2 bg-gray-100/50 p-1 rounded">
        <span className="flex items-center gap-1">
           <span className="text-gray-400">In:</span>
           <span className="font-medium text-gray-700">{formatDate(order.purchaseDate)}</span>
        </span>
        <span className="flex items-center gap-1">
           <span className="text-gray-400">Prev:</span>
           <span className={`font-medium ${isUrgent ? 'text-red-600' : 'text-blue-600'}`}>{formatDate(order.deliveryDate)}</span>
        </span>
      </div>

      {/* Timeline Toggle */}
      <button 
        onClick={() => setShowHistory(!showHistory)} 
        className="text-[9px] text-gray-400 flex items-center gap-1 mb-2 hover:text-gray-600 w-full"
      >
        {showHistory ? <ChevronUp size={10} /> : <ChevronDown size={10} />}
        Histórico de Etapas
      </button>

      {/* Timeline History */}
      {showHistory && order.statusHistory && (
        <div className="bg-gray-50/80 rounded border border-gray-100 p-1.5 mb-2 space-y-1">
            {order.statusHistory.map((hist, i) => (
                <div key={i} className="flex justify-between text-[9px]">
                    <span className="font-medium text-gray-600">{hist.status}</span>
                    <span className="text-gray-400">{formatDateTime(hist.timestamp)}</span>
                </div>
            ))}
        </div>
      )}

      {/* Botões de Ação */}
      <div className="mt-auto flex gap-1">
        {action.next ? (
          <button 
            onClick={handleAction}
            disabled={!canPerformAction()}
            className={`flex-1 py-1 px-2 rounded text-[10px] font-bold uppercase tracking-wide flex items-center justify-center gap-1.5 transition-all active:scale-95 
              ${canPerformAction() ? action.colorClass : 'bg-gray-100 text-gray-400 cursor-not-allowed opacity-70'}`}
          >
            {canPerformAction() ? (
                <>
                    {action.icon && <action.icon size={10} />}
                    {action.label}
                </>
            ) : (
                <>
                    <Lock size={10} />
                    Aguardando
                </>
            )}
          </button>
        ) : (
          <div className="flex-1 text-center py-1 text-[10px] font-bold text-gray-400 uppercase tracking-wide bg-gray-50/50 rounded flex items-center justify-center gap-1 border border-gray-100">
            <CheckCircle size={10} /> Finalizado
          </div>
        )}

        {/* Botão Refazer (Somente SUPERVISOR) */}
        {onRedo && 
         [OrderStatus.FEITOS, OrderStatus.AGUARDANDO, OrderStatus.MONTAGEM, OrderStatus.FINALIZADOS, OrderStatus.AVISADOS].includes(order.status) && 
         user.role === UserRole.SUPERVISOR && (
             <button
                onClick={handleRedoClick}
                className="bg-orange-100 hover:bg-orange-200 text-orange-700 p-1.5 rounded transition-colors border border-orange-200"
                title="Refazer Pedido (Supervisor)"
             >
                 <RotateCcw size={14} />
             </button>
        )}
      </div>
    </div>
  );
};