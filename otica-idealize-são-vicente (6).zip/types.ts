export enum OrderStatus {
  FEITOS = 'FEITOS',
  AGUARDANDO = 'AGUARDANDO',
  MONTAGEM = 'MONTAGEM',
  FINALIZADOS = 'FINALIZADOS',
  AVISADOS = 'AVISADOS',
  ENTREGUES = 'ENTREGUES',
}

export enum SaleType {
  VENDA = 'Venda',
  PASSAGEM = 'Passagem',
  GARANTIA = 'Garantia'
}

export enum DeadlineType {
  PEDIDO = 'Pedido',
  URGENTE = 'Urgente',
  NA_HORA = 'Na Hora'
}

export interface StatusHistoryEntry {
  status: OrderStatus;
  timestamp: number;
}

export interface LensDetails {
  odSph?: string;
  odCyl?: string;
  oeSph?: string;
  oeCyl?: string;
  // Legacy support just in case, though we will try to use structured data
  raw?: string; 
}

export interface Order {
  id: string;
  osNumber: string;
  orderNumber: string; // The primary order number
  additionalOrders?: string[]; // Extra order numbers for multiple glasses in same OS
  customerName?: string; // Kept optional for legacy data compatibility
  saleType: SaleType;
  deadlineType: DeadlineType;
  purchaseDate: string;
  deliveryDate: string;
  status: OrderStatus;
  notes?: string;
  redoReason?: string; // Motivo para refazer o pedido
  lensDetails?: LensDetails; // Grau da lente de estoque (Na Hora)
  createdAt: number;
  updatedAt: number; // For alert calculation
  statusHistory: StatusHistoryEntry[]; // To track when each stage happened
}

export enum UserRole {
  SUPERVISOR = 'SUPERVISOR',
  ADMINISTRATIVO = 'ADMINISTRATIVO',
  MONTAGEM = 'MONTAGEM'
}

export interface User {
  username: string;
  role: UserRole;
  name: string;
}

// Inventory Grid Types
export interface InventoryItem {
  sph: string;
  cyl: string;
  quantity: number;
}