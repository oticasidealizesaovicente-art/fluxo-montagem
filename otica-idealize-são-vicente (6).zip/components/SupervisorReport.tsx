import React, { useState, useMemo } from 'react';
import { Order, OrderStatus } from '../types';
import { ArrowLeft, Clock, BarChart2, Glasses, CheckCircle, Calendar } from 'lucide-react';

interface SupervisorReportProps {
  orders: Order[];
  onBack: () => void;
}

// Helper to format timestamp
const formatTime = (timestamp?: number) => {
  if (!timestamp) return '-';
  const d = new Date(timestamp);
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const hour = String(d.getHours()).padStart(2, '0');
  const min = String(d.getMinutes()).padStart(2, '0');
  return `${day}/${month} ${hour}:${min}`;
};

// Helper to find the latest timestamp for a specific status in history
const getStatusTime = (order: Order, status: OrderStatus) => {
  if (!order.statusHistory) return '-';
  // Find the last entry for this status (in case it went back and forth)
  const entry = [...order.statusHistory].reverse().find(h => h.status === status);
  return entry ? formatTime(entry.timestamp) : '-';
};

// Get YYYY-MM-DD from timestamp
const getDateString = (timestamp: number) => {
    const d = new Date(timestamp);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

export const SupervisorReport: React.FC<SupervisorReportProps> = ({ orders, onBack }) => {
  const [activeTab, setActiveTab] = useState<'timeline' | 'production'>('production'); // Default to production for quick check
  
  // Production Filter State
  const [prodStartDate, setProdStartDate] = useState(() => {
      const d = new Date();
      d.setDate(1); // First day of current month
      return getDateString(d.getTime());
  });
  const [prodEndDate, setProdEndDate] = useState(() => getDateString(Date.now()));

  // --- Timeline Data Logic ---
  const sortedOrders = useMemo(() => {
     return [...orders].sort((a, b) => b.updatedAt - a.updatedAt);
  }, [orders]);

  // --- Production Data Logic ---
  const productionData = useMemo(() => {
      return orders.map(order => {
          let finishedTimestamp: number | undefined;

          // 1. Try to find explicit 'FINALIZADOS' entry in history (The "Concluir" button click)
          // We look for the latest one to allow for re-dos counting as the most recent finish
          const historyEntry = [...(order.statusHistory || [])]
              .reverse()
              .find(h => h.status === OrderStatus.FINALIZADOS);
          
          if (historyEntry) {
              finishedTimestamp = historyEntry.timestamp;
          } 
          // 2. Fallback for legacy/seed data or orders that were moved past FINALIZADOS without history:
          // If the current status implies the montage is done (FINALIZADOS, AVISADOS, ENTREGUES)
          // and no specific history entry exists, use updatedAt as a proxy.
          else if ([OrderStatus.FINALIZADOS, OrderStatus.AVISADOS, OrderStatus.ENTREGUES].includes(order.status)) {
              finishedTimestamp = order.updatedAt;
          }

          if (!finishedTimestamp) return null;

          const finishDate = getDateString(finishedTimestamp);
          
          // Filter by selected date range
          if (prodStartDate && finishDate < prodStartDate) return null;
          if (prodEndDate && finishDate > prodEndDate) return null;

          // Calculate quantity: 1 (Primary) + Additional Orders (filter empty strings just in case)
          const additionalCount = order.additionalOrders?.filter(o => o.trim() !== '').length || 0;
          const quantity = 1 + additionalCount;

          return {
              ...order,
              finishedAt: finishedTimestamp,
              quantity
          };
      }).filter((o): o is NonNullable<typeof o> => o !== null)
      .sort((a, b) => b.finishedAt - a.finishedAt);
  }, [orders, prodStartDate, prodEndDate]);

  const totalProductionCount = productionData.reduce((acc, curr) => acc + curr.quantity, 0);
  const totalOrdersCount = productionData.length;

  const headers = [
    { label: 'OS / Pedidos', width: 'w-48' },
    { label: 'Tipo', width: 'w-24' },
    { label: 'Feitos', status: OrderStatus.FEITOS },
    { label: 'Aguardando', status: OrderStatus.AGUARDANDO },
    { label: 'Montagem', status: OrderStatus.MONTAGEM },
    { label: 'Finalizados', status: OrderStatus.FINALIZADOS },
    { label: 'Avisados', status: OrderStatus.AVISADOS },
    { label: 'Entregues', status: OrderStatus.ENTREGUES },
  ];

  return (
    <div className="flex flex-col h-full bg-brand-light p-4 overflow-hidden">
      
      {/* Top Bar */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 bg-white p-3 rounded-lg shadow-sm border border-gray-200 gap-4">
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-full text-gray-600 transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <div>
            <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
              {activeTab === 'timeline' ? <Clock size={20} className="text-blue-600" /> : <BarChart2 size={20} className="text-brand-teal" />}
              Relatório de Supervisão
            </h2>
            <p className="text-xs text-gray-500">
                {activeTab === 'timeline' ? 'Histórico detalhado de etapas por OS' : 'Contagem de produção (Montagem -> Concluído)'}
            </p>
          </div>
        </div>
        
        {/* Tab Switcher */}
        <div className="flex bg-gray-100 p-1 rounded-lg">
            <button 
                onClick={() => setActiveTab('timeline')}
                className={`px-4 py-1.5 text-sm font-bold rounded-md transition-all ${activeTab === 'timeline' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
                Timeline
            </button>
            <button 
                onClick={() => setActiveTab('production')}
                className={`px-4 py-1.5 text-sm font-bold rounded-md transition-all ${activeTab === 'production' ? 'bg-white text-brand-teal shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
                Produção
            </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 bg-white rounded-lg shadow border border-gray-200 overflow-hidden flex flex-col">
        
        {/* === TAB: TIMELINE === */}
        {activeTab === 'timeline' && (
            <div className="flex flex-col h-full">
                <div className="p-2 bg-blue-50/50 text-xs text-blue-700 border-b border-blue-100 px-4">
                    Mostrando todos os registros ({sortedOrders.length}). Use a busca na tela principal para filtrar por data de compra/entrega.
                </div>
                <div className="overflow-auto flex-1">
                <table className="w-full text-left border-collapse">
                    <thead className="bg-gray-50 sticky top-0 z-10 shadow-sm">
                    <tr>
                        {headers.map((h, idx) => (
                        <th key={idx} className={`p-3 text-xs font-bold text-gray-600 uppercase tracking-wider border-b border-gray-200 ${h.width || ''}`}>
                            {h.label}
                        </th>
                        ))}
                    </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                    {sortedOrders.map((order) => (
                        <tr key={order.id} className="hover:bg-blue-50/50 transition-colors text-xs text-gray-700">
                        <td className="p-3 border-r border-gray-100">
                            <div className="font-bold text-blue-700 mb-0.5">{order.osNumber}</div>
                            <div className="text-gray-500 flex flex-wrap gap-1">
                                <span>{order.orderNumber}</span>
                                {order.additionalOrders?.map(ao => <span key={ao}>, {ao}</span>)}
                            </div>
                        </td>
                        <td className="p-3 border-r border-gray-100">
                            <span className="block font-medium">{order.saleType}</span>
                            <span className="text-[10px] text-gray-400">{order.deadlineType}</span>
                        </td>
                        
                        {/* Status Columns */}
                        <td className="p-3 text-center border-r border-gray-100 font-mono text-gray-500">
                            {getStatusTime(order, OrderStatus.FEITOS)}
                        </td>
                        <td className="p-3 text-center border-r border-gray-100 font-mono text-gray-500">
                            {getStatusTime(order, OrderStatus.AGUARDANDO)}
                        </td>
                        <td className="p-3 text-center border-r border-gray-100 font-mono text-gray-500">
                            {getStatusTime(order, OrderStatus.MONTAGEM)}
                        </td>
                        <td className="p-3 text-center border-r border-gray-100 font-mono text-gray-500">
                            {getStatusTime(order, OrderStatus.FINALIZADOS)}
                        </td>
                        <td className="p-3 text-center border-r border-gray-100 font-mono text-gray-500">
                            {getStatusTime(order, OrderStatus.AVISADOS)}
                        </td>
                        <td className="p-3 text-center font-mono text-gray-500">
                            {getStatusTime(order, OrderStatus.ENTREGUES)}
                        </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
                </div>
            </div>
        )}

        {/* === TAB: PRODUCTION === */}
        {activeTab === 'production' && (
            <div className="flex flex-col h-full">
                {/* Production Toolbar */}
                <div className="p-3 bg-gray-50 border-b border-gray-200 flex flex-wrap gap-4 items-center justify-between">
                    <div className="flex items-center gap-2">
                        <div className="flex items-center gap-2 bg-white px-2 py-1 rounded border border-gray-300">
                            <Calendar size={14} className="text-gray-500" />
                            <span className="text-xs font-bold text-gray-600 uppercase">Período de Conclusão:</span>
                            <input 
                                type="date" 
                                value={prodStartDate}
                                onChange={(e) => setProdStartDate(e.target.value)}
                                className="text-xs border-none focus:ring-0 text-gray-800 font-medium bg-transparent p-0 w-24"
                            />
                            <span className="text-gray-400">-</span>
                            <input 
                                type="date" 
                                value={prodEndDate}
                                onChange={(e) => setProdEndDate(e.target.value)}
                                className="text-xs border-none focus:ring-0 text-gray-800 font-medium bg-transparent p-0 w-24"
                            />
                        </div>
                    </div>

                    <div className="flex gap-4">
                         <div className="bg-blue-50 border border-blue-100 px-4 py-1 rounded flex items-center gap-2">
                             <div className="text-blue-500 bg-white p-1 rounded-full"><CheckCircle size={14} /></div>
                             <div>
                                 <div className="text-[10px] uppercase text-blue-500 font-bold">Ordens</div>
                                 <div className="text-lg font-bold text-blue-700 leading-none">{totalOrdersCount}</div>
                             </div>
                         </div>
                         <div className="bg-green-50 border border-green-100 px-4 py-1 rounded flex items-center gap-2">
                             <div className="text-brand-teal bg-white p-1 rounded-full"><Glasses size={14} /></div>
                             <div>
                                 <div className="text-[10px] uppercase text-brand-teal font-bold">Total Óculos</div>
                                 <div className="text-lg font-bold text-brand-teal leading-none">{totalProductionCount}</div>
                             </div>
                         </div>
                    </div>
                </div>

                <div className="overflow-auto flex-1">
                    <table className="w-full text-left border-collapse">
                        <thead className="bg-gray-50 sticky top-0 z-10 shadow-sm">
                            <tr>
                                <th className="p-3 text-xs font-bold text-gray-600 uppercase tracking-wider border-b border-gray-200">OS / Detalhes</th>
                                <th className="p-3 text-xs font-bold text-gray-600 uppercase tracking-wider border-b border-gray-200">Tipo</th>
                                <th className="p-3 text-xs font-bold text-gray-600 uppercase tracking-wider border-b border-gray-200 text-center">Data Montagem</th>
                                <th className="p-3 text-xs font-bold text-gray-600 uppercase tracking-wider border-b border-gray-200 text-right">Qtd. Óculos</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {productionData.length > 0 ? (
                                productionData.map((order) => (
                                    <tr key={order.id} className="hover:bg-green-50/50 transition-colors text-xs text-gray-700">
                                        <td className="p-3 border-r border-gray-100">
                                            <div className="font-bold text-gray-900">{order.osNumber}</div>
                                            <div className="text-gray-500 text-[10px]">
                                                {order.orderNumber}
                                                {order.additionalOrders?.map(ao => `, ${ao}`)}
                                            </div>
                                        </td>
                                        <td className="p-3 border-r border-gray-100">
                                            <span className="bg-gray-100 px-1.5 py-0.5 rounded border border-gray-200">
                                                {order.saleType}
                                            </span>
                                        </td>
                                        <td className="p-3 border-r border-gray-100 text-center font-mono font-medium">
                                            {formatTime(order.finishedAt)}
                                        </td>
                                        <td className="p-3 text-right">
                                            <span className="font-bold text-brand-teal text-sm bg-brand-light px-2 py-0.5 rounded border border-brand-teal/20">
                                                {order.quantity}
                                            </span>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={4} className="p-10 text-center text-gray-400 italic">
                                        Nenhuma montagem concluída encontrada neste período.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};