import React, { useState, useEffect } from 'react';
import { StorageService } from '../services/storageService';
import { ArrowLeft, AlertTriangle, Lock, Unlock, Plus, Package, X, RefreshCw } from 'lucide-react';
import { User, UserRole } from '../types';

interface InventoryViewProps {
  user: User;
  onBack: () => void;
}

interface CellProps {
  sph: string;
  cyl: string;
  count: number;
  canEdit: boolean;
  onUpdate: (sph: string, cyl: string, newVal: number) => void;
}

// Ranges for Select Inputs (Reposition)
const SPHERE_OPTIONS = [];
for (let i = 4.00; i >= -4.00; i -= 0.25) {
    const val = i === 0 ? '+0.00' : (i > 0 ? `+${i.toFixed(2)}` : i.toFixed(2));
    SPHERE_OPTIONS.push(val);
}

const CYL_OPTIONS = [];
for (let i = 0.00; i >= -2.00; i -= 0.25) {
    CYL_OPTIONS.push(i === 0 ? '-0.00' : i.toFixed(2));
}

const Cell: React.FC<CellProps> = ({ sph, cyl, count, canEdit, onUpdate }) => {
  const isLow = count < 3;
  
  const handleClick = () => {
    if (!canEdit) return;
    
    const input = prompt(`Ajuste manual de estoque\n\nEsférico: ${sph}\nCilíndrico: ${cyl}\n\nQuantidade atual: ${count}\n\nNova quantidade:`, count.toString());
    
    if (input !== null) {
      const newVal = parseInt(input, 10);
      if (!isNaN(newVal) && newVal >= 0) {
        onUpdate(sph, cyl, newVal);
      } else if (input !== '') {
        alert("Por favor insira um número válido.");
      }
    }
  };

  return (
    <td 
      onClick={handleClick}
      className={`
        border border-gray-400 text-center font-bold text-xs p-1 h-6 w-10 
        ${isLow ? 'bg-red-500 text-white' : 'bg-[#92D050] text-gray-900'}
        ${canEdit ? 'cursor-pointer hover:brightness-110 hover:ring-2 hover:ring-blue-500 hover:z-10 relative' : 'cursor-default'}
      `}
      title={canEdit ? "Clique para editar" : "Visualização apenas"}
    >
      {count}
    </td>
  );
};

// --- RESTOCK MODAL COMPONENT ---
interface RestockModalProps {
  onClose: () => void;
  onConfirm: (sph: string, cyl: string, amount: number) => void;
}

const RestockModal: React.FC<RestockModalProps> = ({ onClose, onConfirm }) => {
  const [sph, setSph] = useState('+0.00');
  const [cyl, setCyl] = useState('-0.00');
  const [amount, setAmount] = useState(1);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirm(sph, cyl, amount);
    setAmount(1); 
    alert(`Adicionado: ${amount}un para Sph ${sph} / Cyl ${cyl}`);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm border border-gray-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="bg-brand-teal p-3 flex justify-between items-center text-white">
          <h3 className="font-bold flex items-center gap-2">
            <Package size={18} /> Reposição de Estoque
          </h3>
          <button onClick={onClose} className="text-teal-100 hover:text-white hover:bg-teal-700/50 rounded-full p-1 transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div className="bg-blue-50 text-blue-800 text-xs p-2 rounded border border-blue-100 mb-2">
            Selecione o grau e a quantidade que chegou para adicionar ao estoque atual.
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-600 mb-1">Esférico</label>
              <select 
                value={sph} 
                onChange={e => setSph(e.target.value)}
                className="w-full bg-white border border-gray-300 rounded p-2 text-sm focus:ring-2 focus:ring-brand-teal outline-none"
              >
                {SPHERE_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-600 mb-1">Cilíndrico</label>
              <select 
                value={cyl} 
                onChange={e => setCyl(e.target.value)}
                className="w-full bg-white border border-gray-300 rounded p-2 text-sm focus:ring-2 focus:ring-brand-teal outline-none"
              >
                {CYL_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-600 mb-1">Quantidade a Adicionar</label>
            <div className="flex items-center gap-2">
              <input 
                type="number" 
                min="1" 
                max="100"
                value={amount} 
                onChange={e => setAmount(parseInt(e.target.value) || 0)}
                className="flex-1 bg-white border border-gray-300 rounded p-2 text-sm focus:ring-2 focus:ring-brand-teal outline-none"
              />
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full bg-brand-orange hover:bg-orange-600 text-white font-bold py-2 rounded shadow-md transition-colors flex justify-center items-center gap-2 mt-2"
          >
            <Plus size={18} /> Adicionar ao Estoque
          </button>
        </form>
      </div>
    </div>
  );
};

export const InventoryView: React.FC<InventoryViewProps> = ({ user, onBack }) => {
  const [inventory, setInventory] = useState<Record<string, number> | null>(null);
  const [showRestock, setShowRestock] = useState(false);
  const ranges = StorageService.getInventoryRanges();

  // Permissions
  const isSupervisor = user.role === UserRole.SUPERVISOR;
  const canRestock = user.role === UserRole.SUPERVISOR || user.role === UserRole.ADMINISTRATIVO;

  useEffect(() => {
    // Real-time subscription
    const unsubscribe = StorageService.subscribeToInventory((data) => {
        setInventory(data);
    });
    return () => unsubscribe();
  }, []);

  const handleDirectUpdate = async (sph: string, cyl: string, newVal: number) => {
      await StorageService.setStock(sph, cyl, newVal);
  };

  const handleRestock = async (sph: string, cyl: string, amount: number) => {
      await StorageService.adjustStock(sph, cyl, amount);
  };

  if (!inventory) return <div className="p-4 text-center">Carregando estoque...</div>;

  const getCount = (sph: string, cyl: string) => {
    const rawSph = sph.replace('+', ''); 
    const key = `${parseFloat(rawSph).toFixed(2)}|${cyl}`;
    return inventory[key] ?? 0;
  };

  return (
    <div className="flex flex-col h-full bg-white overflow-hidden relative">
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-gray-200 bg-brand-light">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 hover:bg-gray-200 rounded-full text-gray-600">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h2 className="text-lg font-bold text-brand-teal flex items-center gap-2">
                Estoque de Lentes (Na Hora)
            </h2>
            <div className="flex items-center gap-2 text-[10px] text-gray-500">
                {isSupervisor ? (
                    <span className="flex items-center gap-1 text-green-600 bg-green-50 px-1.5 rounded border border-green-100">
                        <Unlock size={10} /> Edição Total (Supervisor)
                    </span>
                ) : (
                    <span className="flex items-center gap-1 text-gray-500 bg-gray-100 px-1.5 rounded border border-gray-200">
                        <Lock size={10} /> Visualização Protegida
                    </span>
                )}
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
            {canRestock && (
                <button 
                    onClick={() => setShowRestock(true)}
                    className="flex items-center gap-1 bg-brand-orange text-white text-xs font-bold px-3 py-2 rounded hover:bg-orange-600 transition-colors shadow-sm"
                >
                    <Plus size={14} /> Repor Estoque
                </button>
            )}
        </div>
      </div>
      
      {/* Restock Modal */}
      {showRestock && (
          <RestockModal 
            onClose={() => setShowRestock(false)} 
            onConfirm={handleRestock} 
          />
      )}
      
      <div className="flex-1 overflow-auto p-4 bg-brand-light">
        <div className="flex flex-col xl:flex-row gap-8 items-start justify-center">
            
            {/* TABLE NEGATIVO */}
            <div className="bg-white p-1 shadow-md border border-gray-400">
                <div className="bg-brand-orange text-white font-bold text-center border border-gray-500 py-1 mb-1">
                    NEGATIVO (MIOPIA)
                </div>
                <table className="border-collapse table-fixed">
                    <thead>
                        <tr>
                            <th className="w-12 bg-yellow-200 border border-gray-400"></th>
                            {ranges.cylRange.map(cyl => (
                                <th key={cyl} className="bg-yellow-200 border border-gray-400 text-xs font-bold p-1 w-10 text-gray-700">
                                    {cyl}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {ranges.negSphRange.map(sph => (
                            <tr key={sph}>
                                <th className="bg-yellow-200 border border-gray-400 text-xs font-bold p-1 text-gray-700">
                                    {sph}
                                </th>
                                {ranges.cylRange.map(cyl => (
                                    <Cell 
                                        key={`${sph}-${cyl}`} 
                                        sph={sph} 
                                        cyl={cyl} 
                                        count={getCount(sph, cyl)} 
                                        canEdit={isSupervisor}
                                        onUpdate={handleDirectUpdate}
                                    />
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* TABLE POSITIVO */}
            <div className="bg-white p-1 shadow-md border border-gray-400">
                <div className="bg-brand-orange text-white font-bold text-center border border-gray-500 py-1 mb-1">
                    POSITIVO (HIPERMETROPIA)
                </div>
                <table className="border-collapse table-fixed">
                    <thead>
                        <tr>
                            <th className="w-12 bg-yellow-200 border border-gray-400"></th>
                            {ranges.cylRange.map(cyl => (
                                <th key={cyl} className="bg-yellow-200 border border-gray-400 text-xs font-bold p-1 w-10 text-gray-700">
                                    {cyl}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {ranges.posSphRange.map(sph => (
                            <tr key={sph}>
                                <th className="bg-yellow-200 border border-gray-400 text-xs font-bold p-1 text-gray-700">
                                    {sph}
                                </th>
                                {ranges.cylRange.map(cyl => (
                                    <Cell 
                                        key={`${sph}-${cyl}`} 
                                        sph={sph} 
                                        cyl={cyl} 
                                        count={getCount(sph, cyl)} 
                                        canEdit={isSupervisor}
                                        onUpdate={handleDirectUpdate}
                                    />
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

        </div>
        
        <div className="mt-6 text-center text-xs text-gray-500 flex flex-col items-center justify-center gap-1">
            <div className="flex items-center gap-2">
                <AlertTriangle size={14} className="text-brand-orange" />
                <span>O estoque é descontado automaticamente ao salvar uma OS de tipo "Venda" ou "Garantia" com prazo "Na Hora".</span>
            </div>
            {isSupervisor && <span className="text-brand-teal font-bold">Modo Supervisor: Clique em qualquer célula para corrigir/definir o valor total.</span>}
            {canRestock && <span className="text-gray-600">Use o botão <strong>"Repor Estoque"</strong> para adicionar lentes que chegaram (soma ao total).</span>}
            
            <div className="flex items-center gap-2 mt-2">
               <div className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-[#92D050] border border-gray-400"></div>
                  <span>Estoque Normal (3+)</span>
               </div>
               <div className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-red-500 border border-gray-400"></div>
                  <span>Estoque Baixo ({'<'} 3)</span>
               </div>
            </div>
        </div>
      </div>
    </div>
  );
};