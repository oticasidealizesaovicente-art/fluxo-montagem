import React, { useState } from 'react';
import { AuthService } from '../services/authService';
import { User } from '../types';

interface LoginProps {
  onLoginSuccess: (user: User) => void;
}

export const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = AuthService.login(username, password);
    if (user) {
      AuthService.saveUserSession(user);
      onLoginSuccess(user);
    } else {
      setError('Usuário ou senha incorretos.');
    }
  };

  const setDemoUser = (user: string) => {
      setUsername(user);
      setPassword('123'); // Auto-fill password for easier testing
  };

  return (
    <div className="min-h-screen bg-brand-light flex items-center justify-center p-4">
      <div className="bg-white p-8 rounded-xl shadow-xl max-w-sm w-full border-t-4 border-brand-teal">
        
        <h1 className="text-2xl font-bold text-center text-brand-teal mb-1 mt-2 tracking-tight">Otica Idealize</h1>
        <p className="text-center text-gray-400 mb-8 text-xs uppercase tracking-widest font-semibold">São Vicente</p>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1 uppercase tracking-wide">Usuário</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-gray-50 border border-gray-300 rounded-lg p-3 text-gray-900 focus:ring-2 focus:ring-brand-teal focus:border-brand-teal outline-none transition-all"
              placeholder="Seu usuário"
              autoFocus
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1 uppercase tracking-wide">Senha</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-gray-50 border border-gray-300 rounded-lg p-3 text-gray-900 focus:ring-2 focus:ring-brand-teal focus:border-brand-teal outline-none transition-all"
              placeholder="Sua senha"
            />
          </div>
          
          {error && <p className="text-red-500 text-xs font-medium text-center bg-red-50 p-2 rounded border border-red-100">{error}</p>}

          <button
            type="submit"
            className="w-full bg-brand-teal hover:opacity-90 text-white font-bold py-3 rounded-lg transition-all shadow-md mt-2 flex justify-center"
          >
            Entrar no Sistema
          </button>
        </form>
        
        <div className="mt-8 pt-6 border-t border-gray-100 text-center">
          <p className="text-xs text-gray-400 mb-3">Acesso rápido (Demo)</p>
          <div className="flex gap-2 justify-center text-xs font-mono text-gray-600 flex-wrap">
            <button type="button" className="bg-gray-100 px-3 py-1.5 rounded hover:bg-brand-teal hover:text-white transition-colors" onClick={() => setDemoUser('supervisor')}>supervisor</button>
            <button type="button" className="bg-gray-100 px-3 py-1.5 rounded hover:bg-brand-teal hover:text-white transition-colors" onClick={() => setDemoUser('administrativo')}>adm</button>
            <button type="button" className="bg-gray-100 px-3 py-1.5 rounded hover:bg-brand-teal hover:text-white transition-colors" onClick={() => setDemoUser('montagem')}>montagem</button>
          </div>
        </div>
      </div>
    </div>
  );
};