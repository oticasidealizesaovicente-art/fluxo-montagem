import { Order, OrderStatus, SaleType, DeadlineType } from '../types';
import { db } from './firebaseConfig';
import { 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  getDoc,
  updateDoc
} from 'firebase/firestore';

const ORDERS_COLLECTION = 'orders';
const INVENTORY_COLLECTION = 'inventory';
const INVENTORY_DOC_ID = 'main';

// Helper to generate a key for the inventory map
const getInvKey = (sph: string, cyl: string) => `${sph}|${cyl}`;

// Generate initial inventory structure
const generateInitialInventory = (): Record<string, number> => {
  const inventory: Record<string, number> = {};
  const sphRange = [];
  for (let i = -4.00; i <= 4.00; i += 0.25) sphRange.push(i.toFixed(2));
  const cylRange = [];
  for (let i = 0.00; i >= -2.00; i -= 0.25) cylRange.push((i === 0 ? '-0.00' : i.toFixed(2)));

  sphRange.forEach(sph => {
    cylRange.forEach(cyl => {
      inventory[getInvKey(sph, cyl)] = 5;
    });
  });
  return inventory;
};

export const StorageService = {
  // --- ORDER METHODS (REAL-TIME) ---
  
  // Subscribe to all orders. Calls 'callback' whenever data changes in the cloud.
  subscribeToOrders: (callback: (orders: Order[]) => void) => {
    const q = query(collection(db, ORDERS_COLLECTION));
    
    // onSnapshot is the magic that keeps it sync across computers
    return onSnapshot(q, (snapshot) => {
      const orders: Order[] = [];
      snapshot.forEach((doc) => {
        orders.push(doc.data() as Order);
      });
      callback(orders);
    });
  },

  saveOrder: async (order: Order, isNew: boolean = false): Promise<void> => {
    // Save to Firestore
    await setDoc(doc(db, ORDERS_COLLECTION, order.id), order, { merge: true });

    // AUTOMATIC INVENTORY DEDUCTION (Server-like logic handled on client for now)
    if (isNew && order.deadlineType === DeadlineType.NA_HORA && 
       (order.saleType === SaleType.VENDA || order.saleType === SaleType.GARANTIA) &&
       order.lensDetails) {
         
         if (order.lensDetails.odSph && order.lensDetails.odCyl) {
            await StorageService.adjustStock(order.lensDetails.odSph, order.lensDetails.odCyl, -1);
         }
         if (order.lensDetails.oeSph && order.lensDetails.oeCyl) {
            await StorageService.adjustStock(order.lensDetails.oeSph, order.lensDetails.oeCyl, -1);
         }
    }
  },

  deleteOrder: async (id: string): Promise<void> => {
    await deleteDoc(doc(db, ORDERS_COLLECTION, id));
  },

  updateStatus: async (id: string, newStatus: OrderStatus): Promise<void> => {
    const orderRef = doc(db, ORDERS_COLLECTION, id);
    const orderSnap = await getDoc(orderRef);
    
    if (orderSnap.exists()) {
        const order = orderSnap.data() as Order;
        const now = Date.now();
        
        const updatedHistory = order.statusHistory || [];
        updatedHistory.push({ status: newStatus, timestamp: now });

        await updateDoc(orderRef, {
            status: newStatus,
            updatedAt: now,
            statusHistory: updatedHistory
        });
    }
  },

  // --- INVENTORY METHODS (REAL-TIME) ---

  // Subscribe to inventory changes
  subscribeToInventory: (callback: (inventory: Record<string, number>) => void) => {
    const docRef = doc(db, INVENTORY_COLLECTION, INVENTORY_DOC_ID);
    
    return onSnapshot(docRef, (docSnap) => {
        if (docSnap.exists()) {
            callback(docSnap.data() as Record<string, number>);
        } else {
            // Initialize if doesn't exist
            const initial = generateInitialInventory();
            setDoc(docRef, initial).then(() => callback(initial));
        }
    });
  },

  // Retrieve single value (Async)
  getLensStockAsync: async (sph: string, cyl: string): Promise<number> => {
      const rawSph = sph.replace('+', '');
      const valSph = parseFloat(rawSph);
      const valCyl = parseFloat(cyl);

      if (isNaN(valSph) || isNaN(valCyl)) return 0;

      const fmtSph = valSph.toFixed(2);
      let fmtCyl = valCyl.toFixed(2);
      if (valCyl === 0) fmtCyl = "-0.00";

      const key = getInvKey(fmtSph, fmtCyl);
      const docRef = doc(db, INVENTORY_COLLECTION, INVENTORY_DOC_ID);
      const snap = await getDoc(docRef);
      
      if (snap.exists()) {
          const data = snap.data();
          return data[key] ?? 0;
      }
      return 0;
  },

  adjustStock: async (sph: string, cyl: string, amount: number) => {
    const fmtSph = parseFloat(sph.replace('+', '')).toFixed(2);
    let fmtCyl = parseFloat(cyl).toFixed(2);
    if (parseFloat(cyl) === 0) fmtCyl = "-0.00";

    const key = getInvKey(fmtSph, fmtCyl);
    const docRef = doc(db, INVENTORY_COLLECTION, INVENTORY_DOC_ID);

    // Using a transaction/read-write pattern safely
    const snap = await getDoc(docRef);
    if (snap.exists()) {
        const data = snap.data();
        const current = data[key] || 0;
        await updateDoc(docRef, {
            [key]: current + amount
        });
    }
  },

  setStock: async (sph: string, cyl: string, newQuantity: number) => {
    const rawSph = sph.replace('+', '');
    const fmtSph = parseFloat(rawSph).toFixed(2);
    let fmtCyl = parseFloat(cyl).toFixed(2);
    if (parseFloat(cyl) === 0) fmtCyl = "-0.00";

    const key = getInvKey(fmtSph, fmtCyl);
    const docRef = doc(db, INVENTORY_COLLECTION, INVENTORY_DOC_ID);

    await updateDoc(docRef, {
        [key]: newQuantity
    });
  },

  // Helper for grid ranges (Static)
  getInventoryRanges: () => {
     const cylRange = ['-0.00', '-0.25', '-0.50', '-0.75', '-1.00', '-1.25', '-1.50', '-1.75', '-2.00'];
     
     const negSphRange = [];
     for (let i = -0.25; i >= -4.00; i -= 0.25) negSphRange.push(i.toFixed(2));

     const posSphRange = [];
     for (let i = 0.00; i <= 4.00; i += 0.25) posSphRange.push((i===0 ? '+0.00' : '+' + i.toFixed(2)));

     return { cylRange, negSphRange, posSphRange };
  }
};