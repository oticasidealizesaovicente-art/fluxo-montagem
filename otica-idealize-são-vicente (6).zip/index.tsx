import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { LucideProps } from 'lucide-react';

// Polyfill for Lucide icons in case of older envs, though standard ESM imports work.
// The actual icons are imported in components.

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
